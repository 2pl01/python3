# coding=utf-8
"""
    @project: python3
    @Author："东家“
    @file： 百度文档.py
    @date：2024/01/04 15:37
    
"""
import requests

from pprint import pprint
"""

获取数据，获取服务器返回响应数据2 .
开发者工具: response
response.json() 获取响应json字典数据，但是返回数据必须是完整json数据格式 花括号 
response.text 获取响应文本数据，返回字符串 任何时候都可以，但是基本获取网页源代码的时候
response.content 获取响应二进制数据，返回字节



"""

url="https://wenku.baidu.com/gsearch/rec/pcviewdocrec2023"

data={
"sessionId": "2741084368-2741084368",
"docId": "aa31a84bcf84b9d528ea7a2c",
"query": "纳税筹划100篇之21-30篇",
"recPositions": "catalog,toplist"
}

headers= {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537'}
responses=requests.get(url=url,params=data,headers=headers)
print(responses.json())

num=1
# pprint(responses.json()['data']['catalogDoc'])
for index in responses.json()['data']['catalogDoc']:
    pic=index['pic']

    img_content=requests.get(url=pic,headers=headers).content
    with open('img\\'+str(num)+'.jpg',mode='wb')as f:
        f.write(img_content)
    print(pic)
    num +=1

