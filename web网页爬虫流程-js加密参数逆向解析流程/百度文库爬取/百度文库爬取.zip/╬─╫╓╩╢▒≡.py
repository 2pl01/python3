# coding=utf-8
"""
    @project: python3
    @Author："东家“
    @file： 文字识别.py
    @date：2024/01/04 16:53
    
"""
# encoding:utf-8
from pprint import pprint
import requests
import base64
import os
from docx import Document
def get_content(file):
    # client_id 为官网获取的AK， client_secret 为官网获取的SK
    host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=wza8bUAxjcVDO3HhIxSkSN61&client_secret=mp84ltRVLGfSIEp3sORVktKnHsjPSkqG'
    response = requests.get(host)
    access_token = response.json()['access_token']


    '''
    通用文字识别（高精度版）
    '''

    request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic"
    # 二进制方式打开图片文件
    f = open(file, 'rb')
    img = base64.b64encode(f.read())
    params = {"image":img}
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    json_data = requests.post(request_url, data=params, headers=headers).json()
    words= '\n'.join([i['words'] for i in json_data['words_result']])
    return words
content_list=[]
files = os.listdir('img\\')
for file in files:
    filename='img\\'+file
    words = get_content(file=filename)
    print(words)
    content_list.append(words)
doc =Document()
content='\n'.join(content_list)
doc.add_paragraph(content)
doc.save('data.docx')
#pprint(files)
# if response:
#     pprint (response.json())